How to play:

- Load into a map
- Press f6 to open connection GUI
- Follow instructions to host/join a friend through IP

Discord: https://discord.gg/63zE4gY